package tic;

public class moves {
  int x; 
  int y;
  int score;
 
 public moves( ){
	  
	  this.x =0;
	  this.y =0;
	  this.score = 0; 
  }
}
